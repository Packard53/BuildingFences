﻿using System;

namespace BuildingFences
{
    class Program
    {
        /// <summary>
        /// This below is the syntax for a method
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            /* Nuking this line from the original default
            Console.WriteLine("Hello World!");
            */
            var customer1 = new Customer
            {
                FirstName = "FirstName1",
                LastName = "LastName1",
                EmailAddress1 = "EmailAddress1_1",
                Address1 = "Address1_1"
            };
            Console.WriteLine($"CN: {customer1.CustomerID}, EMail: {customer1.EmailAddress1}");

            var customer2 = new Customer
            {
                FirstName = "FirstName2",
                LastName = "LastName2",
                EmailAddress1 = "EmailAddress1_2",
                Address1 = "Address1_2"
            };
            Console.WriteLine($"CN: {customer2.CustomerID}, EMail: {customer2.EmailAddress1}");
            
            //Don't know how to do this so that it pulls the customer identification first and has dropdowns
            var customerProject1 = new CustomerProject
            {


            };
        }
    }
}
