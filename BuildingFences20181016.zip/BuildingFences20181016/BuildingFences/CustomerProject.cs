﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuildingFences
{
    class CustomerProject
    {
        private static short lastCustomerProjectID = 0;
        #region Properties
        ///<summary>
        ///Properties for CustomerProject where this is the project itself
        ///This table links a bunch of stuff together and allows for
        ///manual input
        ///</summary>
        public short CustomerProjectID { get; }
        public    short CustomerID { get; }
        public  DateTime    QuotationDate { get; }
        public  DateTime    EstStartDate { get; set; }
        public  DateTime    EstEndDate { get; set; }
        public  Decimal EstTotalHours { get; set; }
        public  DateTime    ActStartDate { get; set; }
        public  DateTime    ActEndDate { get; set; }
        public  Decimal ActTotalHours { get; set; }
        public  string  Comment { get; set; }
        public  decimal ListPrice { get; private set; }
        public  decimal DepositAmtRequired { get; set; }
        public  decimal DiscountedPrice { get; set; }
        public decimal  CalculatedProjectComponentPrice { get; private set; }
        public  decimal TotalQuotePrice { get; set; }
        public bool QuotationAccepted { get; set; }
        public DateTime QuotationAcceptanceDate { get; set; }

        #endregion
        #region constructor
        public CustomerProject()
        {
            CustomerProjectID = ++lastCustomerProjectID;
            QuotationDate = DateTime.Now;
        }
        #endregion
        #region Methods
        //Method 1 will let you create a new customerProject
        //Method2 will display a list of current customers and let you select 1
        //Method3 will let you manually input the parameter values to build the quote
        //Method4 will take the ProjectComponents associated with this project and sum them

        #endregion
    }
}
