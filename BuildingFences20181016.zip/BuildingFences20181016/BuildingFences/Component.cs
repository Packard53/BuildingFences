﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuildingFences
{
    class Component
    {
        private static short lastComponentID = 0;
        #region Properties
        /// <summary>
        /// Properties for each MaterialType
        /// </summary>
        public short ComponentID { get;  }
        public string Name { get; set; }
        public  string  Comment { get; set; }
        public decimal PremiumFactor { get; set; }
        public decimal FixedPrice { get; set; }

        #endregion
        #region constructor
        public Component()
        {
            ComponentID = ++lastComponentID;

        }

        #endregion
        #region Methods
        //Method 1 will be to manually enter a Name, Comment, PremiumFactor, and FixedPrice and then save it to the database
        //I need to be able to enter multiple components

        #endregion
    }
}
