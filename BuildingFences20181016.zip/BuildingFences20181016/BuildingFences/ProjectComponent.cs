﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuildingFences
{
    public class ProjectComponent
    {
        private static short lastProjectComponentID = 0;
        #region ProjectComponent
        ///<summary>
        ///This is the list of individual items associated with the project.
        ///All entries are links except for units
        /// </summary>
        public short ProjectComponentID { get; }
        public  short CustomerProjectID { get; }
        public  short ComponentID { get; }
        public decimal ComponentUnits { get; set; }
        public decimal ProjectComponentPrice { get; }
        #endregion
        #region constructor
        public ProjectComponent()
        {
            ProjectComponentID = ++lastProjectComponentID;

        }
        #endregion
        #region Methods
        //This is the table that holds the individual components associated with each project
        //Method1 will be to Select the project, select a component, and then enter units
        //Method2 will calculate ProjectComponentPrice = Component.UnitPrice * ProjectComponent.ComponentUnits

        #endregion
    }

}
