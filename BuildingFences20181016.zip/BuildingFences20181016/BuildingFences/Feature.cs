﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuildingFences
{
    class Feature
    {
        private static short lastFeatureID = 0;
        #region
        /// <summary>
        /// Properties for each feature
        /// </summary>
        public  short FeatureID { get; }
        public string Name { get; set; }
        public decimal UnitPrice { get; set; }
        public  int UnitTypeID { get; }
        public string Comment { get; set; }

        #endregion
        #region constructor
        public Feature()
        {
            FeatureID = ++lastFeatureID;

        }
        #endregion
        #region Methods
        //Method1 will be to simply create new Features and have an input for parameter values

        #endregion


    }
}
