﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuildingFences
{
    class UnitType
    {
        private static short lastUnitTypeID = 0;
        #region Properties
        /// <summary>
        /// Defines all properties for class UnitType
        /// </summary>
        public short UnitTypeID { get; }
        public string   Name { get; set; }

        #endregion
        #region constructor
        public UnitType()
        {
            UnitTypeID = ++lastUnitTypeID;

        }
        #endregion
        #region Methods
        //This will be simple - just an input of things like feet, units, pounds, days

        #endregion
    }
}
