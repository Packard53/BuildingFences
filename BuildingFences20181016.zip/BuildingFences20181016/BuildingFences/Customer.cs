﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuildingFences
{
    class Customer
    {
        private static short lastCustomerID = 0;
        #region Properties
        /// <summary>
        /// Properties for each customer
        /// </summary>
        public short  CustomerID { get; }
        public string   FirstName { get; set; }
        public string   LastName { get; set; }
        public  string  Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public string Country { get; set; }
        public string EmailAddress1 { get; set; }
        public string EmailAddress2 { get; set; }
        public string Phone1 { get; set; }
        public string Phone2 { get; set; }
        public DateTime WhenCreated { get; }
        public bool Hidden { get; set; }

        #endregion
        #region constructor
        public Customer()
        {
            CustomerID = ++lastCustomerID;
            WhenCreated = DateTime.Now;
        }
        #endregion
        #region Methods
        //Method 1 will be to add customer details for a newly-created customer
        //Method 2 will be to edit customer details for a newly-created customer
        //note that removing a customer will be denied, although you can set it to Hidden = 1

        #endregion
    }
}
